﻿using System;
using System.Linq;
using exercicios_EF.Data;
using exercicios_EF.Models;

class Program
{
    static void Main()
    {
        bool sair = false;

        while (!sair)
        {
            Console.WriteLine("\n==== Menu CRUD Livros & Editoras ====");
            Console.WriteLine("1 - Inserir Editora");
            Console.WriteLine("2 - Listar Editoras");
            Console.WriteLine("3 - Atualizar Editora");
            Console.WriteLine("4 - Excluir Editora");
            Console.WriteLine("5 - Inserir Livro");
            Console.WriteLine("6 - Listar Livros");
            Console.WriteLine("7 - Atualizar Livro");
            Console.WriteLine("8 - Excluir Livro");
            Console.WriteLine("9 - Buscar Livros por Título");
            Console.WriteLine("10 - Buscar Livros por Autor");
            Console.WriteLine("11 - Buscar Livros por Gênero");
            Console.WriteLine("12 - Listar Livros por Editora");
            Console.WriteLine("13 - Listar Livros Publicados Após um Ano");
            Console.WriteLine("0 - Sair");
            Console.Write("Escolha uma opção: ");

            var opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1": InserirEditora(); break;
                case "2": ListarEditoras(); break;
                case "3": AtualizarEditora(); break;
                case "4": ExcluirEditora(); break;
                case "5": InserirLivro(); break;
                case "6": ListarLivros(); break;
                case "7": AtualizarLivro(); break;
                case "8": ExcluirLivro(); break;
                case "9": BuscarLivroPorTitulo(); break;
                case "10": BuscarLivroPorAutor(); break;
                case "11": BuscarLivroPorGenero(); break;
                case "12": ListarLivrosPorEditora(); break;
                case "13": BuscarLivrosPorAno(); break;
                case "0": sair = true; break;
                default: Console.WriteLine("Opção inválida!"); break;
            }
        }
    }

    // ===== EDITORA =====
    static void InserirEditora()
    {
        Console.Write("Digite o nome da editora: ");
        var nome = Console.ReadLine();

        using (var db = new Contexto())
        {
            var editora = new Editora { Nome = nome };
            db.Editoras.Add(editora);
            db.SaveChanges();
            Console.WriteLine("Editora inserida com sucesso!");
        }
    }

    static void ListarEditoras()
    {
        using (var db = new Contexto())
        {
            var editoras = db.Editoras.ToList();
            foreach (var e in editoras)
            {
                Console.WriteLine($"{e.Id} - {e.Nome}");
            }
        }
    }

    static void AtualizarEditora()
    {
        Console.Write("Digite o ID da editora: ");
        int id = int.Parse(Console.ReadLine());

        using (var db = new Contexto())
        {
            var editora = db.Editoras.Find(id);
            if (editora == null)
            {
                Console.WriteLine("Editora não encontrada!");
                return;
            }

            Console.Write("Digite o novo nome: ");
            editora.Nome = Console.ReadLine();

            db.Editoras.Update(editora);
            db.SaveChanges();
            Console.WriteLine("Editora atualizada com sucesso!");
        }
    }

    static void ExcluirEditora()
    {
        Console.Write("Digite o ID da editora: ");
        int id = int.Parse(Console.ReadLine());

        using (var db = new Contexto())
        {
            var editora = db.Editoras.Find(id);
            if (editora == null)
            {
                Console.WriteLine("Editora não encontrada!");
                return;
            }

            db.Editoras.Remove(editora);
            db.SaveChanges();
            Console.WriteLine("Editora excluída com sucesso!");
        }
    }

    // ===== LIVRO =====
    static void InserirLivro()
    {
        Console.Write("Digite o título: ");
        var titulo = Console.ReadLine();
        Console.Write("Digite o autor: ");
        var autor = Console.ReadLine();
        Console.Write("Digite o ano de publicação: ");
        var ano = int.Parse(Console.ReadLine());
        Console.Write("Digite o gênero: ");
        var genero = Console.ReadLine();
        Console.Write("Digite o ID da editora: ");
        var editoraId = int.Parse(Console.ReadLine());

        using (var db = new Contexto())
        {
            var livro = new Livro
            {
                Titulo = titulo,
                Autor = autor,
                AnoPublicacao = ano,
                Genero = genero,
                EditoraId = editoraId
            };
            db.Livros.Add(livro);
            db.SaveChanges();
            Console.WriteLine("Livro inserido com sucesso!");
        }
    }

    static void ListarLivros()
    {
        using (var db = new Contexto())
        {
            var livros = db.Livros
                .Select(l => new { l.Id, l.Titulo, l.Autor, l.AnoPublicacao, l.Genero, Editora = l.Editora.Nome })
                .ToList();

            foreach (var l in livros)
            {
                Console.WriteLine($"{l.Id} - {l.Titulo} ({l.Autor}, {l.AnoPublicacao}, {l.Genero}) - Editora: {l.Editora}");
            }
        }
    }

    static void AtualizarLivro()
    {
        Console.Write("Digite o ID do livro: ");
        int id = int.Parse(Console.ReadLine());

        using (var db = new Contexto())
        {
            var livro = db.Livros.Find(id);
            if (livro == null)
            {
                Console.WriteLine("Livro não encontrado!");
                return;
            }

            Console.Write("Novo título: ");
            livro.Titulo = Console.ReadLine();
            Console.Write("Novo autor: ");
            livro.Autor = Console.ReadLine();
            Console.Write("Novo ano: ");
            livro.AnoPublicacao = int.Parse(Console.ReadLine());
            Console.Write("Novo gênero: ");
            livro.Genero = Console.ReadLine();

            db.Livros.Update(livro);
            db.SaveChanges();
            Console.WriteLine("Livro atualizado com sucesso!");
        }
    }

    static void ExcluirLivro()
    {
        Console.Write("Digite o ID do livro: ");
        int id = int.Parse(Console.ReadLine());

        using (var db = new Contexto())
        {
            var livro = db.Livros.Find(id);
            if (livro == null)
            {
                Console.WriteLine("Livro não encontrado!");
                return;
            }

            db.Livros.Remove(livro);
            db.SaveChanges();
            Console.WriteLine("Livro excluído com sucesso!");
        }
    }

    // ===== CONSULTAS COM FILTROS =====
    static void BuscarLivroPorTitulo()
    {
        Console.Write("Digite parte do título: ");
        var titulo = Console.ReadLine();

        using (var db = new Contexto())
        {
            var livros = db.Livros.Where(l => l.Titulo.Contains(titulo)).ToList();
            foreach (var l in livros)
            {
                Console.WriteLine($"{l.Id} - {l.Titulo}");
            }
        }
    }

    static void BuscarLivroPorAutor()
    {
        Console.Write("Digite o autor: ");
        var autor = Console.ReadLine();

        using (var db = new Contexto())
        {
            var livros = db.Livros.Where(l => l.Autor == autor).ToList();
            foreach (var l in livros)
            {
                Console.WriteLine($"{l.Id} - {l.Titulo} ({l.Autor})");
            }
        }
    }

    static void BuscarLivroPorGenero()
    {
        Console.Write("Digite o gênero: ");
        var genero = Console.ReadLine();

        using (var db = new Contexto())
        {
            var livros = db.Livros.Where(l => l.Genero == genero).ToList();
            foreach (var l in livros)
            {
                Console.WriteLine($"{l.Id} - {l.Titulo} ({l.Genero})");
            }
        }
    }

    static void ListarLivrosPorEditora()
    {
        Console.Write("Digite o ID da editora: ");
        var editoraId = int.Parse(Console.ReadLine());

        using (var db = new Contexto())
        {
            var livros = db.Livros.Where(l => l.EditoraId == editoraId).ToList();
            foreach (var l in livros)
            {
                Console.WriteLine($"{l.Id} - {l.Titulo}");
            }
        }
    }

    static void BuscarLivrosPorAno()
    {
        Console.Write("Digite o ano mínimo: ");
        var ano = int.Parse(Console.ReadLine());

        using (var db = new Contexto())
        {
            var livros = db.Livros.Where(l => l.AnoPublicacao > ano).ToList();
            foreach (var l in livros)
            {
                Console.WriteLine($"{l.Id} - {l.Titulo} ({l.AnoPublicacao})");
            }
        }
    }
}

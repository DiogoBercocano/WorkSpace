﻿using Microsoft.EntityFrameworkCore;
using exercicios_EF.Models;

namespace exercicios_EF.Data
{
    public class Contexto : DbContext
    {
        public DbSet<Editora> Editoras { get; set; }
        public DbSet<Livro> Livros { get; set; }

        public Contexto()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                "Server=localhost;Database=LivrariaDB;Trusted_Connection=True;TrustServerCertificate=True;");
        }
    }
}

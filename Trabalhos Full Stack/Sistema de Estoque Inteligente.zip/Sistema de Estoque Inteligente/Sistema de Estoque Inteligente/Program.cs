﻿using Microsoft.Extensions.DependencyInjection;
using Repositorio.Data;
using Repositorio.Interfaces;
using Repositorio.Classes;
using Dominio.Models;

namespace SistemaEstoqueInteligente
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var services = new ServiceCollection();
            services.AddDbContext<EstoqueContext>();
            services.AddScoped<IRepositorioProduto, ProdutoRepositorio>();

            var serviceProvider = services.BuildServiceProvider();

            var repositorio = serviceProvider.GetRequiredService<IRepositorioProduto>();
            var contexto = serviceProvider.GetRequiredService<EstoqueContext>();

            Console.WriteLine("=== SISTEMA DE ESTOQUE ===");
            Console.Write("Nome do produto: ");
            string nome = Console.ReadLine();

            Console.Write("Preço: ");
            decimal preco = decimal.Parse(Console.ReadLine());

            Console.Write("Quantidade: ");
            int quantidade = int.Parse(Console.ReadLine());

            var produto = new Produto()
            {
                Nome = nome,
                Preco = preco,
                QuantidadeEstoque = quantidade
            };

            repositorio.Inserir(produto);
            contexto.SaveChanges();

            Console.WriteLine("✅ Produto inserido com sucesso!");
        }
    }
}

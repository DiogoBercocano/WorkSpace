﻿using Dominio.Models;

namespace Repositorio.Interfaces
{
    public interface IRepositorioProduto : IRepositorio<Produto>
    {
    }
}

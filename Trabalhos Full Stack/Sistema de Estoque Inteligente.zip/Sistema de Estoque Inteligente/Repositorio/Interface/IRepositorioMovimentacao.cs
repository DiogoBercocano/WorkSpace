﻿using Dominio.Models;

namespace Repositorio.Interfaces
{
    public interface IRepositorioMovimentacao : IRepositorio<MovimentacaoEstoque>
    {
    }
}

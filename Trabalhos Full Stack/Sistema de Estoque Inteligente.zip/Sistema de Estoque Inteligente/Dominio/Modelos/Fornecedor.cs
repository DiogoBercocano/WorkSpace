﻿using System.Collections.Generic;

namespace Dominio.Models
{
    public class Fornecedor
    {
        public int FornecedorId { get; set; }
        public string Nome { get; set; }
        public string Contato { get; set; }

        public List<Produto> Produtos { get; set; }
    }
}

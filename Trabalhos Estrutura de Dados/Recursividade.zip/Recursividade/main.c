#include <stdio.h>
#include <stdlib.h>

void exercicio1();
void exercicio2();
void exercicio3();
void exercicio4();
void exercicio5();
void exercicio6();
void exercicio7();
void exercicio8();

int main() {
    int op;

    do {
	     system("cls");
	     printf("=== Menu ===\n");
	     printf("1 - Rotina recursiva para calcular a somat�ria\n");
		printf("2 - Algoritmo recursivo para c�lculo do fatorial\n");
		printf("3 - Fa�a uma fun��o recursiva que calcule e retorne o N-�simo termo da sequ�ncia Fibonacci\n");
		printf("4 - Fa�a uma fun��o recursiva que permita somar os elementos de um vetor de inteiros.\n");
		printf("5 - Crie um programa em C que receba um vetor de n�meros reais com 10 elementos.\n");
		printf("6 - Fa�a uma fun��o recursiva que receba um n�mero inteiro positivo N e imprima todos os n�meros naturais de 0 at� N em ordem crescente.\n");
		printf("7 - Fa�a uma fun��o recursiva que receba um n�mero inteiro positivo N e imprima todos os n�meros naturais de 0 at� N em ordem decrescente.\n");
		printf("8 - Fa�a uma fun��o recursiva que receba uma string e imprima a mesma na ordem contr�ria.\n");
	     printf("0 - Sair\n");
		printf("Escolha: ");
	     scanf("%d", &op);

        switch(op) {
	          case 1:
	          	exercicio1();
	          	break;
	          case 2:
	               exercicio2();
	               break;
	     	case 3:
	            	exercicio3();
	               break;
	          case 4:
	            	exercicio4();
	               break;
	          case 5:
	            	exercicio5();
	               break;
	   		case 6:
	   			exercicio6();
	               break;
	          case 7:
	            	exercicio7();
	               break;
	          case 8:
	            	exercicio8();
	               break;
	          case 0:
	               printf("Saindo...\n");
	               break;
	          default:
	               printf("Opcao invalida!\n");
     	}
        	system("pause");
	} while(op != 0);

return 0;
}


#include <stdio.h>

int somatoria(int n) {
    if (n == 1) {
        return 1;
    } else {
        return n + somatoria(n - 1);
    }
}

void exercicio1() {
    int n;
    printf("Informe um Numero: ");
    scanf("%d", &n);
    printf("Somatoria: %d\n", somatoria(n));
}


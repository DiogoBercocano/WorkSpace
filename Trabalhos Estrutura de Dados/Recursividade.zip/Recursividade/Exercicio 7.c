#include <stdio.h>

void imprimirDecrescente(int n) {
    if (n >= 0) {
        printf("%d ", n);
        imprimirDecrescente(n - 1);
    }
}

void exercicio7() {
    int n;
    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Numero invalido! Digite um numero >= 0.\n");
        return;
    }

    printf("Numeros de %d ate 0 em ordem decrescente:\n", n);
    imprimirDecrescente(n);
    printf("\n");
}


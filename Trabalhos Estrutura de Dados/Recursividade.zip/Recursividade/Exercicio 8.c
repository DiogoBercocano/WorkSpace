#include <stdio.h>
#include <string.h>

void imprimirContrario(char str[], int i) {
    if (i < 0) 
        return;
    printf("%c", str[i]);
    imprimirContrario(str, i - 1);
}

void exercicio8() {
    char str[100];
    printf("Digite uma string: ");
    scanf(" %[^\n]", str);

    printf("String invertida: ");
    imprimirContrario(str, strlen(str) - 1);
    printf("\n");
}


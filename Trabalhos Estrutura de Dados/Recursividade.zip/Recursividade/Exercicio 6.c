#include <stdio.h>

void imprimirCrescente(int n) {
    if (n >= 0) {
        imprimirCrescente(n - 1);
        printf("%d ", n);
    }
}

void exercicio6() {
    int n;
    printf("Digite um numero positivo: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Numero invalido! Digite um numero >= 0.\n");
        return;
    }

    printf("Numeros de 0 ate %d em ordem crescente:\n", n);
    imprimirCrescente(n);
    printf("\n");
}


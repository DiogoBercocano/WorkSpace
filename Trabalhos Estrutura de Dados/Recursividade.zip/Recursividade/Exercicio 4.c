#include <stdlib.h>
#include <stdio.h>

int somar(int vet[], int n) {
    if (n == 0)
        return 0;
    else
        return vet[n - 1] + somar(vet, n - 1);
}

void exercicio4() {
    int vet[5];
    int i;

    printf("Digite 5 numeros inteiros:\n");
    for (i = 0; i < 5; i++) {
        printf("Elemento %d: ", i + 1);
        scanf("%d", &vet[i]);
    }

    int resultado = somar(vet, 5);
    printf("Soma dos elementos do vetor: %d\n", resultado);
}


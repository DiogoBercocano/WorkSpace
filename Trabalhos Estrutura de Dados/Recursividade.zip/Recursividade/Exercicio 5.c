#include <stdlib.h>
#include <stdio.h>

void inverter(float vet[], int i, int j) {
    if (i >= j) return;

    float temp = vet[i];
    vet[i] = vet[j];
    vet[j] = temp;

    inverter(vet, i + 1, j - 1);
}

void exercicio5() {
    float vet[10];
    int i;
    printf("Digite 10 numeros reais:\n");
    for (i = 0; i < 10; i++) {
        printf("Elemento %d: ", i + 1);
        scanf("%f", &vet[i]);
    }

    inverter(vet, 0, 9);

    printf("Vetor invertido:\n");
    for (i = 0; i < 10; i++) {
        printf("%.2f ", vet[i]);
    }
    printf("\n");
}


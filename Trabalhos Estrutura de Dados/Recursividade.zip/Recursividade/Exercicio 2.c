#include <stdio.h>

int fatorial_recursivo(int n) {
    if (n == 0 || n == 1)
        return 1;
    return n * fatorial_recursivo(n - 1);
}

int fatorial_iterativo(int n) {
    int fat = 1;
    for (int i = 1; i <= n; i++) {
        fat *= i;
    }
    return fat;
}

void exercicio2() {
    int n, opcao;

    printf("Digite um numero positivo: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Nao existe fatorial de numero negativo.\n");
        return;
    }

    printf("Escolha o metodo:\n");
    printf("1 - Recursivo\n");
    printf("2 - Nao Recursivo\n");
    printf("Opcao: ");
    scanf("%d", &opcao);

    if (opcao == 1)
        printf("Fatorial (recursivo) de %d = %d\n", n, fatorial_recursivo(n));
    else if (opcao == 2)
        printf("Fatorial (nao recursivo) de %d = %d\n", n, fatorial_iterativo(n));
    else
        printf("Opcao invalida!\n");
}


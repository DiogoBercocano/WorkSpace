#include <stdio.h>

int fibonacci(int n) {
    if (n < 2) 
        return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}


void exercicio3() {
    int n;
    printf("Digite a posicao N da sequencia Fibonacci: ");
    scanf("%d", &n);

    if (n < 0) {
        printf("Posicao invalida! Digite um numero >= 0.\n");
        return;
    }

    printf("O termo %d da sequencia Fibonacci e: %d\n", n, fibonacci(n));
}


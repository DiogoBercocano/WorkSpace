#include <stdio.h>
#include <stdlib.h>

struct no {
    int valor;
    struct no *prox;
};
typedef struct no Lista;

// ---- Fun��es base ----

Lista* criarLista() {
    return NULL;
}

int listaVazia(Lista *lista) {
    return (lista == NULL);
}

int totalElementosLista(Lista *lista) {
    int total = 0;
    Lista *p;  // vari�vel fora do for
    for (p = lista; p != NULL; p = p->prox)
        total++;
    return total;
}

void exibirLista(Lista *lista) {
    Lista *p;
    if (listaVazia(lista))
        printf("Lista vazia.\n");
    else {
        for (p = lista; p != NULL; p = p->prox)
            printf("%d -> ", p->valor);
        printf("NULL\n");
    }
}

Lista* inserirNoOrdenado(Lista *lista, int valor) {
    Lista *novo, *atual;
    novo = (Lista*) malloc(sizeof(Lista));
    novo->valor = valor;
    novo->prox = NULL;

    if (lista == NULL || valor < lista->valor) {
        novo->prox = lista;
        return novo;
    }

    atual = lista;
    while (atual->prox != NULL && atual->prox->valor < valor)
        atual = atual->prox;

    novo->prox = atual->prox;
    atual->prox = novo;
    return lista;
}

Lista* removerElemento(Lista *lista, int valor) {
    Lista *atual, *anterior;
    if (listaVazia(lista))
        return lista;

    atual = lista;
    anterior = NULL;

    while (atual != NULL && atual->valor != valor) {
        anterior = atual;
        atual = atual->prox;
    }

    if (atual == NULL) {
        printf("Elemento %d n�o encontrado.\n", valor);
        return lista;
    }

    if (anterior == NULL)
        lista = atual->prox;
    else
        anterior->prox = atual->prox;

    free(atual);
    printf("Elemento %d removido.\n", valor);
    return lista;
}

Lista* alterarElemento(Lista *lista, int antigo, int novo) {
    Lista *p;
    for (p = lista; p != NULL; p = p->prox) {
        if (p->valor == antigo) {
            p->valor = novo;
            printf("Elemento %d alterado para %d.\n", antigo, novo);
            return lista;
        }
    }
    printf("Elemento %d n�o encontrado.\n", antigo);
    return lista;
}

void localizarElemento(Lista *lista, int valor) {
    Lista *p;
    for (p = lista; p != NULL; p = p->prox) {
        if (p->valor == valor) {
            printf("Elemento %d encontrado!\n", valor);
            return;
        }
    }
    printf("Elemento %d n�o encontrado.\n", valor);
}

// ---- Programa principal ----

int main() {
    Lista *lista = criarLista();
    int opcao, valor, novoValor;

    do {
        printf("\n--- MENU LISTA ENCADEADA ---\n");
        printf("1 - Inserir elemento (ordenado)\n");
        printf("2 - Alterar elemento\n");
        printf("3 - Excluir elemento\n");
        printf("4 - Localizar elemento\n");
        printf("5 - Exibir todos elementos\n");
        printf("6 - Exibir quantidade de elementos\n");
        printf("0 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("Digite o valor: ");
                scanf("%d", &valor);
                lista = inserirNoOrdenado(lista, valor);
                break;

            case 2:
                printf("Valor a alterar: ");
                scanf("%d", &valor);
                printf("Novo valor: ");
                scanf("%d", &novoValor);
                lista = alterarElemento(lista, valor, novoValor);
                break;

            case 3:
                printf("Valor a excluir: ");
                scanf("%d", &valor);
                lista = removerElemento(lista, valor);
                break;

            case 4:
                printf("Valor a localizar: ");
                scanf("%d", &valor);
                localizarElemento(lista, valor);
                break;

            case 5:
                exibirLista(lista);
                break;

            case 6:
                printf("Quantidade de elementos: %d\n", totalElementosLista(lista));
                break;

            case 0:
                printf("Encerrando...\n");
                break;

            default:
                printf("Op��o inv�lida.\n");
        }
    } while (opcao != 0);

    return 0;
}


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TF1 1000
#define TF10 10000
#define TF25 25000
#define TF50 50000

void insertSort(int vet[], int tam) {
    int i, esq, elemento, dir, movi = 0;
    double tempoExecucao;

    clock_t tempoInicial = clock();
    printf("\n<< Ordenando com InsertSort >>\n");

    for (dir = 1; dir < tam; dir++) {
        elemento = vet[dir];
        esq = dir - 1;
        while (esq >= 0 && vet[esq] > elemento) {
            vet[esq + 1] = vet[esq];
            esq--;
            movi++;
        }
        vet[esq + 1] = elemento;
        movi++;
    }

    tempoExecucao = ((double)clock() - tempoInicial) / CLOCKS_PER_SEC;

    printf("-- Tempo de Execucao: %f segundos --\n", tempoExecucao);
    printf("-- Quantidade de Movimentacoes: %d --\n", movi);
}

void selectSort(int vets[], int tam) {
    int i, elemento, esq, dir, movi = 0;
    double tempoExecucao;

    clock_t tempoInicial = clock();
    printf("\n<< Ordenando com SelectSort >>\n");

    for (esq = 0; esq < tam; esq++) {
        for (dir = esq + 1; dir < tam; dir++) {
            if (vets[esq] > vets[dir]) {
                elemento = vets[esq];
                vets[esq] = vets[dir];
                vets[dir] = elemento;
                movi++;
            }
        }
    }

    tempoExecucao = ((double)clock() - tempoInicial) / CLOCKS_PER_SEC;

    printf("-- Tempo de Execucao: %f segundos --\n", tempoExecucao);
    printf("-- Quantidade de Movimentacoes: %d --\n", movi);
}

void bubbleSort(int vetb[], int tam) {
    int elemento, houveTroca, indice, movi = 0;
    int tamanho = tam;
    double tempoExecucao;

    clock_t tempoInicial = clock();
    printf("\n<< Ordenando com BubbleSort >>\n");

    do {
        houveTroca = 0;
        for (indice = 0; indice < tamanho - 1; indice++) {
            if (vetb[indice] > vetb[indice + 1]) {
                elemento = vetb[indice];
                vetb[indice] = vetb[indice + 1];
                vetb[indice + 1] = elemento;
                houveTroca = 1;
                movi++;
            }
        }
        tamanho--;
        movi += 2;
    } while (houveTroca == 1);

    tempoExecucao = ((double)clock() - tempoInicial) / CLOCKS_PER_SEC;

    printf("-- Tempo de Execucao: %f segundos --\n", tempoExecucao);
    printf("-- Quantidade de Movimentacoes: %d --\n", movi);
}

void clonar_vetor(int vet[], int vets[], int vetb[], int tam) {
    int i;
    for (i = 0; i < tam; i++) {
        vets[i] = vet[i];
        vetb[i] = vet[i];
    }
}

void carregar_vetor(int vet[], int tam) {
    int i;
    double tempoExecucao;

    clock_t tempoInicial = clock();
    printf("\n<< Carregando Vetor >>\n");
    srand(time(NULL));
    for (i = 0; i < tam; i++) {
        vet[i] = rand() % tam;
    }
    tempoExecucao = ((double)clock() - tempoInicial) / CLOCKS_PER_SEC;
    printf("Tempo de Execucao: %f segundos\n", tempoExecucao);
}

void exibir_vetores(int vet[], int tam) {
    int i;
    printf("\n<< Vetores (primeiros e ultimos elementos) >>\n");

    for (i = 0; i < 10 && i < tam; i++) {
        printf("V%d:[%d]\n", i, vet[i]);
    }

    if (tam > 20) {
        printf("...\n");
        for (i = tam - 10; i < tam; i++) {
            printf("V%d:[%d]\n", i, vet[i]);
        }
    }
}

int main() {
    int op, op2;
    int vet1[TF1], vet10[TF10], vet25[TF25], vet50[TF50];
    int vets1[TF1], vets10[TF10], vets25[TF25], vets50[TF50];
    int vetb1[TF1], vetb10[TF10], vetb25[TF25], vetb50[TF50];

    printf("Qual tamanho de vetor deseja?\n1 - 1k\n2 - 10k\n3 - 25k\n4 - 50k\n");
    scanf("%d", &op);

    switch (op) {
        case 1:
            carregar_vetor(vet1, TF1);
            printf("\nDeseja exibir o vetor antes da ordenacao? 1-SIM ou 2-NAO: ");
            scanf("%d", &op2);
            if (op2 == 1) exibir_vetores(vet1, TF1);
            clonar_vetor(vet1, vets1, vetb1, TF1);
            insertSort(vet1, TF1);
            selectSort(vets1, TF1);
            bubbleSort(vetb1, TF1);
            break;

        case 2:
            carregar_vetor(vet10, TF10);
            printf("\nDeseja exibir o vetor antes da ordenacao? 1-SIM ou 2-NAO: ");
            scanf("%d", &op2);
            if (op2 == 1) exibir_vetores(vet10, TF10);
            clonar_vetor(vet10, vets10, vetb10, TF10);
            insertSort(vet10, TF10);
            selectSort(vets10, TF10);
            bubbleSort(vetb10, TF10);
            break;

        case 3:
            carregar_vetor(vet25, TF25);
            printf("\nDeseja exibir o vetor antes da ordenacao? 1-SIM ou 2-NAO: ");
            scanf("%d", &op2);
            if (op2 == 1) exibir_vetores(vet25, TF25);
            clonar_vetor(vet25, vets25, vetb25, TF25);
            insertSort(vet25, TF25);
            selectSort(vets25, TF25);
            bubbleSort(vetb25, TF25);
            break;

        case 4:
            carregar_vetor(vet50, TF50);
            printf("\nDeseja exibir o vetor antes da ordenacao? 1-SIM ou 2-NAO: ");
            scanf("%d", &op2);
            if (op2 == 1) exibir_vetores(vet50, TF50);
            clonar_vetor(vet50, vets50, vetb50, TF50);
            insertSort(vet50, TF50);
            selectSort(vets50, TF50);
            bubbleSort(vetb50, TF50);
            break;

        default:
            printf("\n<< Opcao Invalida >>\n");
            break;
    }

    printf("\n<< Encerrando Sistema de Ordenacao de Vetores >>\n");
    return 0;
}


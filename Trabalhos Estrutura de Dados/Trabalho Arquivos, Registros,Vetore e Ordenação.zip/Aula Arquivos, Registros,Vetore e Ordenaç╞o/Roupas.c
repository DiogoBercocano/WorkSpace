#include <stdio.h>

#define TF 100

struct Roupas {
    int id;
    char nome[100];
    char tamanho[50];
    float preco;
    int ativo; // 1 = ativo, 0 = exclu�do
};

struct Roupas roupas[TF];
int qtd = 0;

// ---------- Fun��es ----------
void inserir() {
    if (qtd < TF) {
        roupas[qtd].id = qtd + 1;
        printf("\nNome: ");
        fflush(stdin);
        gets(roupas[qtd].nome);
        printf("Tamanho: ");
        gets(roupas[qtd].tamanho);
        printf("Preco: ");
        scanf("%f", &roupas[qtd].preco);
        roupas[qtd].ativo = 1;
        qtd++;
        printf("\nCadastro realizado!\n");
    } else {
        printf("\nLimite atingido!\n");
    }
}

void exibir() {
    int i;
    printf("\n--- Lista de Roupas ---\n");
    for (i = 0; i < qtd; i++) {
        if (roupas[i].ativo == 1) {
            printf("\nID: %d", roupas[i].id);
            printf("\nNome: %s", roupas[i].nome);
            printf("\nTamanho: %s", roupas[i].tamanho);
            printf("\nPreco: %.2f\n", roupas[i].preco);
        }
    }
}

void localizar() {
    int id, i, achou = 0;
    printf("\nInforme o ID da roupa: ");
    scanf("%d", &id);
    for (i = 0; i < qtd; i++) {
        if (roupas[i].id == id) {
            printf("\nNome: %s", roupas[i].nome);
            printf("\nTamanho: %s", roupas[i].tamanho);
            printf("\nPreco: %.2f\n", roupas[i].preco);
            achou = 1;
            break;
        }
    }
    if (!achou) printf("\nNao encontrado!\n");
}

void alterar() {
    int id, i;
    printf("\nInforme o ID da roupa que deseja alterar: ");
    scanf("%d", &id);
    for (i = 0; i < qtd; i++) {
        if (roupas[i].id == id) {
            printf("\nNovo nome: ");
            fflush(stdin);
            gets(roupas[i].nome);
            printf("Novo tamanho: ");
            gets(roupas[i].tamanho);
            printf("Novo preco: ");
            scanf("%f", &roupas[i].preco);
            printf("\nRegistro alterado!\n");
            return;
        }
    }
    printf("\nNao encontrado!\n");
}

void excluir() {
    int id, i;
    printf("\nInforme o ID da roupa para excluir: ");
    scanf("%d", &id);
    for (i = 0; i < qtd; i++) {
        if (roupas[i].id == id) {
            roupas[i].ativo = 0;
            printf("\nRegistro excluido (logico)!\n");
            return;
        }
    }
    printf("\nNao encontrado!\n");
}

void ativar() {
    int id, i;
    printf("\nInforme o ID da roupa para ativar: ");
    scanf("%d", &id);
    for (i = 0; i < qtd; i++) {
        if (roupas[i].id == id) {
            roupas[i].ativo = 1;
            printf("\nRegistro reativado!\n");
            return;
        }
    }
    printf("\nNao encontrado!\n");
}

void ordenar() {
    int i, j;
    struct Roupas temp;
    for (i = 0; i < qtd - 1; i++) {
        for (j = i + 1; j < qtd; j++) {
            if (roupas[i].preco > roupas[j].preco) {
                temp = roupas[i];
                roupas[i] = roupas[j];
                roupas[j] = temp;
            }
        }
    }
    printf("\nRegistros ordenados por preco!\n");
}

void gravarArquivo() {
    FILE *arq = fopen("Roupas.bin", "wb");
    if (arq == NULL) {
        printf("\nErro ao abrir arquivo!\n");
        return;
    }
    fwrite(&qtd, sizeof(int), 1, arq);
    fwrite(roupas, sizeof(struct Roupas), qtd, arq);
    fclose(arq);
    printf("\nRegistros gravados com sucesso!\n");
}

void lerArquivo() {
    FILE *arq = fopen("Roupas.bin", "rb");
    if (arq == NULL) {
        printf("\nErro ao abrir arquivo!\n");
        return;
    }
    fread(&qtd, sizeof(int), 1, arq);
    fread(roupas, sizeof(struct Roupas), qtd, arq);
    fclose(arq);
    printf("\nRegistros carregados com sucesso!\n");
}

void excluirArquivo() {
    if (remove("Roupas.bin") == 0)
        printf("\nArquivo excluido com sucesso!\n");
    else
        printf("\nErro ao excluir arquivo!\n");
}

// ---------- Programa Principal ----------
int main() {
    int opcao;
    do {
        printf("\n===== MENU =====\n");
        printf("1 - Inserir roupa\n");
        printf("2 - Exibir roupas\n");
        printf("3 - Localizar roupa\n");
        printf("4 - Alterar roupa\n");
        printf("5 - Excluir roupa\n");
        printf("6 - Ativar roupa\n");
        printf("7 - Ordenar por preco\n");
        printf("8 - Gravar em arquivos\n");
        printf("9 - Carregar arquivos\n");
        printf("10 - Excluir arquivos\n");
        printf("0 - Sair\n");
        printf("Opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1: inserir(); 
				break;
            case 2: exibir(); 
				break;
            case 3: localizar(); 
				break;
            case 4: alterar(); 
				break;
            case 5: excluir(); 
				break;
            case 6: ativar(); 
				break;
            case 7: ordenar(); 
				break;
            case 8: gravarArquivo(); 
				break;
            case 9: lerArquivo(); 
				break;
            case 10: excluirArquivo(); 
				break;
            case 0: printf("\nSaindo...\n"); 
				break;
            default: printf("\nOpcao invalida!\n");
        }
    } while (opcao != 0);

}

